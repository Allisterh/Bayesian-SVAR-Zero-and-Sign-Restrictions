function PofTau=GetPofTau(H,OrthcompH,Tau);
PofTau=H*H'+OrthcompH*OrthcompH'*Tau;



